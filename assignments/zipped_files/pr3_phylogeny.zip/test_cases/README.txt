TEST 1: Simple base case
TEST 2: Degenerate case (A - B - C - D), all dist = 1
TEST 3: Trivial 3-node test case.
TEST 4: medium test case, nodes = 4
TEST 5: medium test case, nodes = 5
TEST 6: medium test case, nodes = 5
TEST 7: Primates + bovine + mouse

