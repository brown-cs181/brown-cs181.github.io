# This example shell script directly calls the python interpreter
# on a hypothetical python script that will conduct the UPGMA algorithm.
# You'll need to edit this file for the language of your choosing.
# Come to office hours if you need additional clarification.
python upgma.py ${1} ${2}
