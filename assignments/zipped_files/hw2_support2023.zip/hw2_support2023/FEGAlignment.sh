
python3 fegalignment.pyc ${1} ${2}
