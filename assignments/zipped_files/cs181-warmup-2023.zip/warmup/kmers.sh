# Fill in the blank line with the command or commands that will run your program. Make sure it takes in an argument $1, which refers to the file containing the gene sequence. Print your results to standard out.

# For example, if your program is written in Python, you might put
# python kmers.py $1
###############################



###############################

# You can run your script by running
# sh kmers.sh Tthermophilus.txt
