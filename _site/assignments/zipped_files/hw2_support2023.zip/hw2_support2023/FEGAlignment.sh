
python3 fegalignment_obs.py ${1} ${2}
